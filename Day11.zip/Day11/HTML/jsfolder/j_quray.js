$(document).ready(function(){
    $("#a").click(function(){
    
       $("#b").hide(3000);
       $(this).attr("disabled",true);
       $("#c").attr("disabled",false);
    });
       
  
    $("#c").click(function(){
        
        $("#b").show(3000);
        $(this).attr("disabled",true);
       $("#a").attr("disabled",false);
  
    });
  
    $("#d").click(function(){
        
        $("#b").width(600);
        $("#b").height(600);
    });
  
  
    $("#e").click(function(){
        $("#b").width(250);
        $("#b").height(250);
        
  
    });
  });